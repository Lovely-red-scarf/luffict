from django.conf.urls import url
from app01 import views
from django.contrib import admin
urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r'coursedetail/(?P<pk>\d+)/$',views.CourseDetial.as_view()),

    url(r'course/$',views.Course_all.as_view()),

    url(r'degreecourse/(?P<pk>\d+)/$',views.DegreeCourse.as_view()),
]